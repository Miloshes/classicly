// initialize Facebook
  FB.init({
    appId  : FACEBOOK_APP_ID,
    status : true, // check login status
    cookie : true, // enable cookies to allow the server to access the session
    xfbml  : true  // parse XFBML
  });

