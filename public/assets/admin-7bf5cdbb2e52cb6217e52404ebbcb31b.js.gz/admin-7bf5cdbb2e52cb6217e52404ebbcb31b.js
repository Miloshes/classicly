$(function(){
  $("table tr:nth-child(even)").addClass("even");
  $("table tr:nth-child(odd)").addClass("odd");
});
