var _paq = _paq || [];

function performableAudioBookCollectionViewed(){
    _paq.push(["trackConversion", {
    id: "0sHLMn4f9EhR",
    value: null
  }]);
}

function performableAudioBookViewed(){
  _paq.push(["trackConversion", {
    id: "5qyvbH7cYnGc",
    value: null
  }]);
}

function performableAudioBookMP3Downloaded(){
    _paq.push(["trackConversion", {
    id: "78m8kN8ULZRh",
    value: null
    }])
}
;
